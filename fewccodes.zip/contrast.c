#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

void read_image(char *);
float measure_contrast();

int row,col;
float **mat;
char s_name[20];

int main()
{
  float cont=0.0;

  printf("Enter image name(.raw file)::");
  scanf("%s",s_name);

  printf("Enter Column and Row Value::");
  scanf("%d%d",&col,&row);

  read_image(s_name);
  cont=measure_contrast();

  printf("Measure of Contrast:: %f \n",cont);

  return(0);
}

void read_image(char *s_name)
{
  FILE *fp;
  int i,j;

  mat=(float **)malloc(row*sizeof(float *));
  for(i=0;i<row;i++)
    mat[i]=(float *)malloc(col*sizeof(float));

  fp=fopen(s_name,"r");
  if(fp==NULL)
    {
      printf("FILE OPEN ERROR...");
      exit(0);
    }

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      fread(&mat[i][j],sizeof(float),1,fp);     

  fclose(fp);
}

float measure_contrast()
{
  float c=0.0,temp=0.0;
  int i,j;

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      temp=temp+(float)(pow((i-j),2)*(mat[i][j])/(row*col));

  c=temp/((row-1)*(col-1));

  return(c);
}
