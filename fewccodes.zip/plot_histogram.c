#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

void memory_allocation(void);
void read_image(char *);
void histogram(void);
void max_freq(void);
void plot_histogram(void);
void write_image(void);

int row,col,max,min,arr[256];
float **inmat,**outmat;
int **mat;

int main()
{
  char str[50];

  printf("Enter input image(raw file):: ");
  scanf("%s",str);
  printf("Enter Image Size(row & col)::");
  scanf("%d%d",&row,&col);

  memory_allocation();
  read_image(str);
  histogram();
  max_freq();
  plot_histogram();
  write_image();

  free(inmat);
  free(outmat);

  return(0);
}

void memory_allocation()
{
  int i,j;

  inmat=(float **)malloc(row*sizeof(float *));
  for(i=0;i<row;i++)
    inmat[i]=(float *)malloc(col*sizeof(float));

  outmat=(float **)malloc(256*sizeof(float *));
  for(i=0;i<256;i++)
    outmat[i]=(float *)malloc(256*sizeof(float));

  for(i=0;i<row;i++) for(j=0;j<col;j++) inmat[i][j]=255.0;
  for(i=0;i<256;i++) for(j=0;j<256;j++) outmat[i][j]=255.0;

  mat=(int **)malloc(row*sizeof(int *));
  for(i=0;i<row;i++)
    mat[i]=(int *)malloc(col*sizeof(int));

  for(i=0;i<row;i++) for(j=0;j<col;j++) mat[i][j]=0;

}

void read_image(char *s_name)
{
  FILE *fp;
  int i,j;

  fp=fopen(s_name,"r");
  if(fp==NULL)
    {
      printf("FILE OPEN ERROR...");
      exit(0);
    }

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      fread(&inmat[i][j],sizeof(float),1,fp); 

  fclose(fp);
}

void write_image()
{
  FILE *fp;
  int i,j,l;

  fp=fopen("histogram.raw","w");
  if(fp==NULL)
    {
      printf("FILE OPEN ERROR...");
      exit(0);
    }

  for(i=0;i<256;i++)
    for(j=0;j<256;j++)
      fwrite(&outmat[i][j],sizeof(float),1,fp);     

  fclose(fp);

  printf("\nOutput file::histogram.raw  row & col :: 256  256\n\n");
}

void histogram(void)
{
  int i,j;

  for(i=0;i<=255;i++)  
    arr[i]=0;

  for(i=0;i<row;i++) for(j=0;j<col;j++) mat[i][j]=(int)inmat[i][j];

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      arr[mat[i][j]]=arr[mat[i][j]]+1;

  //  for(i=0;i<256;i++)  printf("Freq of %d = %d\n",i,arr[i]);
}

void max_freq()
{
  int i,j;

  max=-999;
  min=999;

  for(i=0;i<256;i++) { if(arr[i]>max) max=arr[i]; if(arr[i]<min) min=arr[i]; }

  printf("\nMax frequency= %d  Min frequency= %d\n",max,min);
}

void plot_histogram()
{
  int i,j;
  int freq=0,freq_norm=0;

  for(i=0;i<256;i++)
    {
      freq=arr[i];

      freq_norm=(int)255.0*((freq-min)/(float)(max-min));

      for(j=0;j<freq_norm;j++)
	outmat[255-j][i]=0.0;
    }
}
