#include<stdio.h>
#include<malloc.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

void read_image(char *);
float** padding(float **);
void gaussian_mask(void);
float luminance(float **);
float contrast(float **,float);
float** normalization(float**,float,float);
float structure(float **,float **);
float cal_ssim(void);
float cal_mssim(void);

float mx,my,sx,sy,sxy,c1,c2,k1,k2;
float **g_mask,**mat,**ssim;
int row,col,h,w;

int main()
{
  int i,j,m,n;
  char s1[50],s2[50];
  float **pad_mat1,**pad_mat2;
  float **a,**b,mssim=0.0;

  k1=0.01; k2=0.03;                          
  c1=pow((k1*255),2); c2=pow((k2*255),2);    

  printf("Enter Original and Enhanced Images(.raw file)::");
  scanf("%s%s",s1,s2);
  printf("Enter Column & Row Size::");
  scanf("%d%d",&col,&row);
  printf("Enter local block size(ex. 11,11)::");
  scanf("%d%d",&h,&w);

  a=(float **)malloc(h*sizeof(float *));
  for(i=0;i<h;i++)
    a[i]=(float *)malloc(w*sizeof(float));

  b=(float **)malloc(h*sizeof(float *));
  for(i=0;i<h;i++)
    b[i]=(float *)malloc(w*sizeof(float));

  for(i=0;i<h;i++) for(j=0;j<w;j++) a[i][j]=b[i][j]=0.0;

  mat=(float **)malloc(row*sizeof(float *));
  for(i=0;i<row;i++)
    mat[i]=(float *)malloc(col*sizeof(float));

  pad_mat1=(float **)malloc((row+h-1)*sizeof(float *));
  for(i=0;i<row+h-1;i++)
    pad_mat1[i]=(float *)malloc((col+w-1)*sizeof(float));

  pad_mat2=(float **)malloc((row+h-1)*sizeof(float *));
  for(i=0;i<row+h-1;i++)
    pad_mat2[i]=(float *)malloc((col+w-1)*sizeof(float));

  ssim=(float **)malloc(row*sizeof(float *));
  for(i=0;i<row;i++)
    ssim[i]=(float *)malloc(col*sizeof(float));

  read_image(s1);
  pad_mat1=padding(mat);
  read_image(s2);
  pad_mat2=padding(mat);

  gaussian_mask();

  for(i=0;i<row;i++)
    {
      for(j=0;j<col;j++)
	{
	  for(m=0;m<h;m++)
	    {
	      for(n=0;n<w;n++)
		{
		  a[m][n]=pad_mat1[i+m][j+n];   
		  b[m][n]=pad_mat2[i+m][j+n];
		}                               
	    } 

	  mx=my=sx=sy=sxy=0.0;

	  mx=luminance(a);                       
	  my=luminance(b);
	  sx=contrast(a,mx);
	  sy=contrast(b,my);
	  a=normalization(a,mx,sx);
	  b=normalization(b,my,sy);
	  sxy=structure(a,b);
	  ssim[i][j]=cal_ssim();
	}
    }                                        //for(i=0;i<row;i++)for(j=0;j<col;j++)printf("%f,",ssim[i][j]);
  mssim=cal_mssim();

  printf("SSIM = %f",mssim);

  return(0);
}

void gaussian_mask(void)
{
  float pi=3.14285,sigma=1.5;
  int i,j,ii,jj;

  ii=(int)h/2;
  jj=(int)w/2;

  g_mask=(float **)malloc(h*sizeof(float *));
  for(i=0;i<h;i++)
    g_mask[i]=(float *)malloc(w*sizeof(float));

  for(i=0;i<h;i++)
    for(j=0;j<w;j++)
      g_mask[i][j]=(float)(1/(2*pi*sigma*sigma))*(exp(-((i-ii)*(i-ii)+(j-jj)*(j-jj))/(2*sigma*sigma)));

  //  for(i=0;i<11;i++){for(j=0;j<11;j++)printf("%.3f ",g_mask[i][j]);printf("\n");}

}

float luminance(float **arr)
{
  int i,j;
  float l=0.0;

  for(i=0;i<h;i++)
    for(j=0;j<w;j++)
      l=l+g_mask[i][j]*arr[i][j];               //printf("%f,",l);

  return(l/(h*w));
}

float contrast(float **arr,float l)
{
  int i,j;
  float c=0.0;

  for(i=0;i<h;i++)
    for(j=0;j<w;j++)
      c=c+(g_mask[i][j]*pow((arr[i][j]-l),2));           //printf("%f,",sqrt(c));

  return(sqrt(c/(h*w)));
}

float** normalization(float **arr,float l,float c)
{
  int i,j;
  float **temp;

  temp=(float **)malloc(h*sizeof(float *));
  for(i=0;i<h;i++)
    temp[i]=(float *)malloc(w*sizeof(float));

  for(i=0;i<h;i++)
    for(j=0;j<w;j++)
      temp[i][j]=(arr[i][j]-l)/(c+0.1);

  return(temp);
}

float structure(float **a,float **b)
{
  int i,j;
  float s=0.0;

  for(i=0;i<h;i++)
    for(j=0;j<w;j++)
      s=s+(g_mask[i][j]*(a[i][j]-mx)*(b[i][j]-my));

  return(s/(h*w));
}

void read_image(char *str)
{
  int i,j;
  FILE *fp;

  fp=fopen(str,"r");
  if(fp==NULL)
    {
      printf("File Open Error...");
      exit(0);
    }

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      fread(&mat[i][j],sizeof(float),1,fp);

  fclose(fp);
}

float cal_ssim()
{
  int i,j;
  float temp;

  temp=((2*mx*my+c1)*(2*sxy+c2))/((mx*mx+my*my+c1)*(sx*sx+sy*sy+c2));       //printf("%f,",temp);

  return(temp);
}

float cal_mssim()
{
  int i,j;
  float mssim=0.0;

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      mssim=mssim+ssim[i][j];

  return(mssim/(row*col));
}

float** padding(float **mat)
{
  int i,j,val;
  float **padded_mat;
  FILE *fp;

  val=(int)(h/2);

  padded_mat=(float **)malloc((row+h-1)*sizeof(float *));
  for(i=0;i<row+h-1;i++)
    padded_mat[i]=(float *)malloc((col+w-1)*sizeof(float));

  for(i=0;i<row+h-1;i++)
    for(j=0;j<col+w-1;j++)
      padded_mat[i][j]=0.0;

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      padded_mat[i+val][j+val]=mat[i][j];

  fp=fopen("ssim_out.raw","w");
  for(i=0;i<row+h-1;i++)
    for(j=0;j<col+w-1;j++)
      fwrite(&padded_mat[i][j],sizeof(float),1,fp);
  fclose(fp);

  return(padded_mat);
}

