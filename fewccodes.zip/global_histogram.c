#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

void read_image();
void histogram(void);
void hist_equ(void);
void write_image(void);

int row,col,max_pix,arr[256];
int **mat;
char s[20],s1[20],s2[50];


int main()
{
  int i,j;

  printf("Enter input image(pgm file):: ");
  scanf("%s",s);

  read_image();
  histogram();
  hist_equ();
  write_image();

  return(0);
}

void read_image()
{
  FILE *fp;
  int i,j;

  fp=fopen(s,"r");
  if(fp==NULL)
    {
      printf("Getting Error to open input file !!!!!");
      exit(0);
    }
  fgets(s1,10,fp);
  fgets(s2,50,fp);
  fscanf(fp,"%d",&col);
  fscanf(fp,"%d",&row);
  fscanf(fp,"%d",&max_pix);

  mat=(int **)malloc(row*sizeof(int *));
  for(i=0;i<row;i++)
    mat[i]=(int *)malloc(col*sizeof(int));


  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      fscanf(fp,"%d",&mat[i][j]);

  fclose(fp);
}

void histogram(void)
{
  int i,j;

  for(i=0;i<=255;i++)  
    arr[i]=0;

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      arr[mat[i][j]]=arr[mat[i][j]]+1;

  //  for(i=0;i<256;i++)
  //    printf("Freq of %d = %d\n",i,arr[i]);
}

void hist_equ(void)
{
float *p;
 int imgsize,i,j,k;

imgsize = row*col;
p=(float *)malloc(max_pix*sizeof(float));

for(i=0; i<max_pix; i++) p[i] = (float)arr[i]/(float)imgsize;
for(i=1; i<max_pix; i++) p[i] = p[i] + p[i-1];
for(i=0; i<max_pix; i++) p[i] = max_pix*p[i] + 0.5;

for(i=0; i<row; i++){
for(j=0; j<col; j++){
        k = mat[i][j];
        mat[i][j] = p[k];
        }       }

}

void write_image(void)
{
 
  FILE *fp;
  int i,j;
 
  fp=fopen("global_hist_out","w");
  if(fp==NULL)
    {
      printf("Getting Error to open output file !!!!!");
      exit(0);
    }

 fprintf(fp,"%s",s1);
 fprintf(fp,"%s",s2);
 fprintf(fp,"%d %d\n%d",col,row,max_pix);

 for(i=0;i<row;i++)
   for(j=0;j<col;j++)
     fprintf(fp,"\n%d",mat[i][j]);

 fclose(fp);

}
