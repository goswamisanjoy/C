#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

void memory_allocation();
void read_image(char *);
void image_padding();
void LoG_mask();
void enhancement();
void maxmin(float **);
void write_image();


float **inmat,**outmat,**paddedmat,**mask, **out1;
int row,col,m_size;
float max,min;

int main()
{
  char str[50];

  printf("Enter Input Image(.raw file)::");
  scanf("%s",str);
  printf("Enter Image Size(ROW & COL)::");
  scanf("%d%d",&row,&col);
  printf("Enter mask size(odd, preferably 5)::");
  scanf("%d",&m_size);

  memory_allocation();
  read_image(str);
  image_padding();
  LoG_mask();
  enhancement();
  write_image();

  free(inmat);
  free(outmat);
  free(paddedmat);
  free(out1);

  //  printf("\n\nOutput Image:: image_diff.raw  Row= %d  Col= %d\n\n",row,col);

  return 0;
}

void memory_allocation()
{
  int i,j;

  inmat=(float **)malloc(row*sizeof(float *));
  for(i=0;i<row;i++)
    inmat[i]=(float *)malloc(col*sizeof(float));  

  outmat=(float **)malloc(row*sizeof(float *));
  for(i=0;i<row;i++)
    outmat[i]=(float *)malloc(col*sizeof(float));
   
  for(i=0;i<row;i++) for(j=0;j<col;j++)  inmat[i][j]=outmat[i][j]=0.0;

  paddedmat=(float **)malloc((row+2*(m_size-1))*sizeof(float *));
  out1=(float **)malloc((row+2*(m_size-1))*sizeof(float *));
  for(i=0;i<row+2*(m_size-1);i++)
    {
      paddedmat[i]=(float *)malloc((col+2*(m_size-1))*sizeof(float));
      out1[i]=(float *)malloc((col+2*(m_size-1))*sizeof(float));
    }

  for(i=0;i<row+2*(m_size-1);i++) for(j=0;j<col+2*(m_size-1);j++) paddedmat[i][j]=out1[i][j]=0.0;

}

void read_image(char *s_name)
{
  FILE *fp;
  int i,j;

  fp=fopen(s_name,"r");
  if(fp==NULL)
    {
      printf("FILE OPEN ERROR...");
      exit(0);
    }

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      fread(&inmat[i][j],sizeof(float),1,fp); 

  fclose(fp);
}

void write_image()
{
  FILE *fp;
  int i,j,l;

  fp=fopen("LoG_enhancement.raw","w");
  if(fp==NULL)
    {
      printf("FILE OPEN ERROR...");
      exit(0);
    }

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      fwrite(&outmat[i][j],sizeof(float),1,fp);     
 
  fclose(fp);

  printf("\nOutput file::LoG_enhancement.raw  row & col :: %d %d\n\n",row,col);
}

void image_padding()
{
  int i,j;

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      paddedmat[i+m_size-1][j+m_size-1]=inmat[i][j];
}


void LoG_mask()
{
  int i,j,var;
  float sigma;

  printf("Enter Sigma(mask_size>=6*sigma, preferably 0.5)::");
  scanf("%f",&sigma);

  mask=(float **)malloc(m_size*sizeof(float *));
  for(i=0;i<m_size;i++)
    mask[i]=(float *)malloc(m_size*sizeof(float));

  var=m_size/2;

  for(i=-var;i<=var;i++)
    for(j=-var;j<=var;j++)
      mask[i+var][j+var]=((i*i+j*j-2*sigma*sigma)/pow(sigma,4.0))*exp(-(i*i+j*j)/(2.0*sigma*sigma));

  printf("\n***** LoG MASK *****\n\n");
  for(i=0;i<m_size;i++) { for(j=0;j<m_size;j++) printf("%.1f  ",mask[i][j]); printf("\n"); }
}


void enhancement()
{
  int i,j,k,l;
  float sum;
  //float mask[5][5]={0,0,-1,0,0,0,-1,-2,-1,0,-1,-2,16,-2,-1,0,-1,-2,-1,0,0,0,-1,0,0};

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      {
	sum=0.0;
	for(k=0;k<m_size;k++)
	  for(l=0;l<m_size;l++)
	    sum+=paddedmat[i+k][j+l]*mask[k][l];

	out1[i][j]=sum;
      }

  for(i=0;i<row;i++) for(j=0;j<col;j++) outmat[i][j]=out1[i+(m_size/2)][j+(m_size/2)];   //shifting

  maxmin(outmat);

  for(i=0;i<row;i++) 
    for(j=0;j<col;j++)
      {
	outmat[i][j]= 255.0*(outmat[i][j]-min)/(max-min);    //scaling
	outmat[i][j]=inmat[i][j]-outmat[i][j];              // LoG unsharp masking
      } 
  maxmin(outmat);

  for(i=0;i<row;i++) for(j=0;j<col;j++) outmat[i][j]= 255.0*(outmat[i][j]-min)/(max-min);    //scaling

}

void maxmin(float **a)
{
  int i,j;

  max=a[0][0];
  min=a[0][0];

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      {
	if(a[i][j]>max) max=a[i][j];
	if(a[i][j]<min) min=a[i][j];
      }

  printf("\nMax Pixel= %f    Min Pixel= %f\n",max,min);
}


