#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

void memory_allocation();
void read_image(char *);
void create_mask();
void image_padding();
void difference_of_gaussians();
void write_image();
void find_mean();


float **inmat,**paddedmat,**outmat,**C_mask,**S_mask;
int row,col,C_rad,S_rad;
float scale_fact,lambda;

int main()
{
  int i;
  float sum=0.0;
  char str[50];

  printf("Enter Input Image(.raw file)::");
  scanf("%s",str);
  printf("Enter Image Size(ROW & COL)::");
  scanf("%d%d",&row,&col);
  printf("Enter the following Parameters::\n");
  printf("\nCenter Radius(preferably 2)::");            //This value may be 1,2,3,2
  scanf("%d",&C_rad);                                   //Combination of (C_radius,S_radius)=>(1,2),(2,3),(3,4),(2,4)
  printf("\nSurround Radius(preferably 4)::");          //This value may be 2,3,4,4
  scanf("%d",&S_rad);
  printf("\nScaling Factor(preferably 0.85)::");
  scanf("%f",&scale_fact);
  //  printf("Number of level to decompose the image(preferably 4)::");
  //  scanf("%d",&level);
  //  printf("\nWeighting parameter(preferably 1)::");      //May also be the image variance
  //  scanf("%f",&lambda);


  //  for(i=0;i<level;i++)
  //    {
  //      row=row/(i+1);
  //      col=col/(i+1);

      memory_allocation();
      create_mask();
      read_image(str);
      image_padding();
      difference_of_gaussians();
      find_mean();
      write_image();
  
      free(inmat);
      free(outmat);
      free(paddedmat);
      free(C_mask);
      free(S_mask);
      //    }

      //  for(i=0;i<level;i++) sum+=lambda*MEAN[i];

      //  wlf=sum/level;

      //  printf("\nThe Weighted-level Contrast::%f\n",wlf);

  return 0;
}

void memory_allocation()
{
  int i,j;

  inmat=(float **)malloc(row*sizeof(float *));
  for(i=0;i<row;i++)
    inmat[i]=(float *)malloc(col*sizeof(float));  

  outmat=(float **)malloc(row*sizeof(float *));
  for(i=0;i<row;i++)
    outmat[i]=(float *)malloc(col*sizeof(float));

  for(i=0;i<row;i++) for(j=0;j<col;j++) inmat[i][j]=outmat[i][j]=0.0;

  C_mask=(float **)malloc((6*C_rad+1)*sizeof(float *));
  for(i=0;i<6*C_rad+1;i++)
    C_mask[i]=(float *)malloc((6*C_rad+1)*sizeof(float));

  for(i=0;i<6*C_rad+1;i++) for(j=0;j<6*C_rad+1;j++) C_mask[i][j]=0.0;

  S_mask=(float **)malloc((6*S_rad+1)*sizeof(float *));
  for(i=0;i<6*S_rad+1;i++)
    S_mask[i]=(float *)malloc((6*S_rad+1)*sizeof(float));

  for(i=0;i<6*S_rad+1;i++) for(j=0;j<6*S_rad+1;j++) S_mask[i][j]=0.0;

  paddedmat=(float **)malloc((row+6*S_rad)*sizeof(float *));
  for(i=0;i<row+6*S_rad;i++)
    paddedmat[i]=(float *)malloc((col+6*S_rad)*sizeof(float));

  for(i=0;i<row+6*S_rad;i++) for(j=0;j<col+6*S_rad;j++) paddedmat[i][j]=0.0;

  //  MEAN=(float *)malloc(level*sizeof(float));

  //  for(i=0;i<level;i++) MEAN[i]=0.0;

}

void create_mask()
{
  int i,j;
  float temp;

  temp=scale_fact*pow((C_rad/(float)S_rad),2.0);   

  for(i=0;i<6*C_rad+1;i++)
    for(j=0;j<6*C_rad+1;j++)
      C_mask[i][j]=(float)exp(-pow(((i-3*C_rad)/(float)C_rad),2.0)-pow(((j-3*C_rad)/(float)C_rad),2.0));

  for(i=0;i<6*S_rad+1;i++)
    for(j=0;j<6*S_rad+1;j++)
      S_mask[i][j]=temp*(exp(-pow(((i-3*S_rad)/(float)S_rad),2.0)-pow(((j-3*S_rad)/(float)S_rad),2.0)));

  printf("\nThis is Central Mask::\n");
  for(i=0;i<6*C_rad+1;i++){ for(j=0;j<6*C_rad+1;j++) printf("%.2f ",C_mask[i][j]); printf("\n"); } 
  printf("\nThis is Surrounding Mask::\n");
  for(i=0;i<6*S_rad+1;i++){ for(j=0;j<6*S_rad+1;j++) printf("%.2f ",S_mask[i][j]); printf("\n"); }

}

void read_image(char *s_name)
{
  FILE *fp;
  int i,j;

  fp=fopen(s_name,"r");
  if(fp==NULL)
    {
      printf("FILE OPEN ERROR...");
      exit(0);
    }

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      fread(&inmat[i][j],sizeof(float),1,fp); 

  fclose(fp);
}

void write_image()
{
  FILE *fp;
  int i,j,l;

  fp=fopen("output.raw","w");
  if(fp==NULL)
    {
      printf("FILE OPEN ERROR...");
      exit(0);
    }

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      fwrite(&outmat[i][j],sizeof(float),1,fp);     

  fclose(fp);

  printf("\nOutput file::output.raw  row & col :: %d %d\n\n",row,col);
}


void image_padding()
{
  int i,j;

  for(i=0;i<row;i++) for(j=0;j<col;j++) paddedmat[i+3*S_rad][j+3*S_rad]=inmat[i][j];
  //  for(i=0;i<3*S_rad;i++) for(j=0;j<col;j++) { paddedmat[i][j+3*S_rad]=inmat[0][j]; paddedmat[row+6*S_rad-i-1][j]=inmat[row-1][j]; }
  //  for(i=0;i<row+6*S_rad;i++) for(j=0;j<3*S_rad;j++) { paddedmat[i][j]=paddedmat[i][3*S_rad]; paddedmat[i][col+3*S_rad+j]=paddedmat[i][col+3*S_rad-1]; }

}

void difference_of_gaussians()
{
  int i,j,k,l;
  float Rc,Rs;

  for(i=3*S_rad;i<row+3*S_rad;i++)
    for(j=3*S_rad;j<col+3*S_rad;j++)
      {
	Rc=Rs=0.0;
	for(k=-3*C_rad;k<=3*C_rad;k++)
	  for(l=-3*C_rad;l<=3*C_rad;l++)
	    Rc+=C_mask[k+3*C_rad][l+3*C_rad]*paddedmat[i+k][j+l];

	for(k=-3*S_rad;k<=3*S_rad;k++)
	  for(l=-3*S_rad;l<=3*S_rad;l++)
	    Rs+=S_mask[k+3*S_rad][l+3*S_rad]*paddedmat[i+k][j+l];          

	outmat[i-3*S_rad][j-3*S_rad]=(float)(Rc-Rs);
      }

}

void find_mean()
{
  int i,j;
  float sum=0.0,mean=0.0;

  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      sum+=outmat[i][j];

  mean=sum/(row*col);

  printf("\nMean Value of the WLF for this level::%f",mean);

}
