#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<malloc.h>

void read_image(void);
void pad_image(void);
void histogram(int,int);
void hist_equ(int,int);
void write_image(void);
void find_maxmin(int *,int);

int row,col,max_pix,m,n,max_val,min_val,addl_row,addl_col;
int **mat,**pad_mat,arr[256],*temp_arr;
float p[256];
char s[20],s1[20],s2[50];


int main()
{
  int i,j;

  printf("Enter input image(pgm file):: ");
  scanf("%s",s);
  printf("Enter local block size (m,n)[***Should be Square and of ODD Length***]::");
  scanf("%d%d",&m,&n);

  temp_arr=(int *)malloc((m*n)*sizeof(int));

  read_image();

  /*  if(row%m != 0 && col%n != 0)
    {
      addl_row = m - row%m;
      addl_col = n - col%n;
    }
  else
    {
      addl_row = 0;
      addl_col = 0;
      }*/                                

  pad_image();

  for(i=0;i<row;i++)
    {
      for(j=0;j<col;j++)
	{
	  histogram(i,j);
	  hist_equ(i,j);                       
	}
    }

  write_image();

  return(0);
}

void read_image()
{
  FILE *fp;
  int i,j;

  fp=fopen(s,"r");
  if(fp==NULL)
    {
      printf("Getting Error to open input file !!!!!");
      exit(0);
    }
  fgets(s1,10,fp);
  fgets(s2,50,fp);
  fscanf(fp,"%d",&col);
  fscanf(fp,"%d",&row);
  fscanf(fp,"%d",&max_pix);

  mat=(int **)malloc(row*sizeof(int *));
  for(i=0;i<row;i++)
    mat[i]=(int *)malloc(col*sizeof(int));


  for(i=0;i<row;i++)
    for(j=0;j<col;j++)
      fscanf(fp,"%d",&mat[i][j]);

  fclose(fp);
}

void pad_image()
{
  int i,j,new_row,new_col;

  new_row = row+(m-1);
  new_col = col+(n-1);

  pad_mat=(int **)malloc(new_row*sizeof(int *));
  for(i=0;i<new_row;i++)
    pad_mat[i]=(int *)malloc(new_col*sizeof(int));

  for(i=0;i<new_row;i++) for(j=0;j<new_col;j++) pad_mat[i][j]=0;

  for(i=0;i<row;i++) for(j=0;j<col;j++) pad_mat[i+m/2][j+n/2]=mat[i][j];
 
  //  write_image();

}
void histogram(int r,int c)
{
  int i,j;

  for(i=0;i<256;i++)  
    arr[i]=0;

  for(i=0;i<m;i++)
    for(j=0;j<n;j++)
      arr[pad_mat[i+r][j+c]]=arr[pad_mat[i+r][j+c]]+1;

  //  for(i=0;i<256;i++)
  //    printf("Freq of %d = %d\n",i,arr[i]);
}

void hist_equ(int r, int c)
{
  int i,j,k;

  for(i=0;i<256;i++) p[i]=0.0;

  for(i=0;i<m*n;i++) temp_arr[i]=0;
  for(i=0;i<m;i++) for(j=0;j<n;j++) temp_arr[i*n+j]= pad_mat[i+r][j+c];

  find_maxmin(temp_arr,(m*n));

  for(i=0; i<256; i++) p[i] = (float)arr[i]/(float)(m*n);
  /*  for(i=min_val+1; i<=max_val; i++) p[i] = p[i] + p[i-1];
      for(i=min_val; i<=max_val; i++) p[i] = min_val+(max_val-min_val)*p[i];*/

  for(i=1; i<=255; i++) p[i] = p[i] + p[i-1];
  for(i=0; i<=255; i++) p[i] = 255*p[i]+0.5;

  k=pad_mat[r+m/2][c+n/2];
  pad_mat[r+m/2][c+n/2]=p[k];

  /*  for(i=0; i<m; i++)
    {
      for(j=0; j<n; j++)
	{
	  k = pad_mat[i+r][j+c];
	  pad_mat[i+r][j+c] = p[k];
	}
	}*/
}

void write_image(void)
{
  FILE *fp;
  int i,j;
 
  fp=fopen("local_hist_out","w");
  if(fp==NULL)
    {
      printf("Getting Error to open output file !!!!!");
      exit(0);
    }

 fprintf(fp,"%s",s1);
 fprintf(fp,"%s",s2);
 fprintf(fp,"%d %d\n%d",col,row,max_pix);

 for(i=0;i<row;i++)
   for(j=0;j<col;j++)
     fprintf(fp,"\n%d",pad_mat[i+m/2][j+n/2]);

 fclose(fp);

}

void find_maxmin(int *a, int x)
{
  int i,max,min;

  max=a[0];
  min=a[0];

  for(i=1;i<x;i++)
    {
      if(a[i]>=max) max = a[i];
      if(a[i]<min) min = a[i];
    }

  max_val=max;
  min_val=min;
}

